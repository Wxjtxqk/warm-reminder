function removeKeywordModal() {
    const modal = document.getElementById("keywords-modal");

    if (modal) {
            modal.remove();
            console.log("removed keywords modal | https://discord.gg/tqHPXPGW | discord: wxjtxqk || https://kaku.lol/warm-reminder");
    }
}

setInterval(removeKeywordModal, 1500);